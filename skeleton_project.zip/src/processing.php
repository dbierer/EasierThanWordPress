<?php
// add pre-processing logic based on URL here:
/*
switch (TRUE) {
    // example:
    case strpos($uri, 'contact') :
        // do something with $body
        break;
    default :
        // fall through
}
*/
